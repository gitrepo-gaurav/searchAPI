package itunes;

import java.util.List;

import innerparameter.Terminologies;
import outerparameters.LookUpParameters;
import outerparameters.SearchParameters;

class BuildingParaString {
    public static String buildLookUpStringParams(LookUpParameters params) {
        throw new UnsupportedOperationException("The lookup method is not yet implemented.");
    }

    public static String buildSearchStringParams(SearchParameters params) {
        StringBuilder resultQuery = new StringBuilder();
        buildTerms(params.getTerms(), resultQuery);
        resultQuery.append(params.getCountry().createSearchParameter()).append("&");
        resultQuery.append(params.getMedia().createSearchParameter()).append("&");


        resultQuery.append(params.getLang().createSearchParameter());
        return resultQuery.toString();
    }

    private static void buildTerms(List<String> terms, StringBuilder resultQuery) {
        if (terms != null) {
            resultQuery.append(new Terminologies(terms).createSearchParameter()).append("&");
        } else {
            System.out.println("Problem in term");
        }
    }
}
