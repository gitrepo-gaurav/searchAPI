package itunes;

import com.google.gson.Gson;

import outerparameters.LookUpParameters;
import outerparameters.SearchParameters;
import result.MultipleResults;

import static itunes.BuildingParaString.buildLookUpStringParams;
import static itunes.BuildingParaString.buildSearchStringParams;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SearchApi {
    //    TODO: query string as configurable
    private static final String searchUrl = "https://itunes.apple.com/search?";
    private static final String lookupUrl = "https://itunes.apple.com/lookup?";
    private static final Logger logger = Logger.getLogger(SearchApi.class.getName());

    public static MultipleResults search(SearchParameters params) throws IOException {
        URL url;
        url = createUrl(searchUrl, buildSearchStringParams(params));
        HttpURLConnection connection = openConnection(url);
        return parseResponseData(readResponse(connection));
    }

    public static MultipleResults lookup(LookUpParameters params) throws IOException {
        URL url = createUrl(lookupUrl, buildLookUpStringParams(params));
        HttpURLConnection connection = openConnection(url);
        return parseResponseData(readResponse(connection));
    }

    private static HttpURLConnection openConnection(URL url) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) url.openConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return connection;
    }

    private static MultipleResults parseResponseData(String data) {
        Gson gson = new Gson();
        return gson.fromJson(data, MultipleResults.class);
    }

    private static String readResponse(HttpURLConnection connection) throws IOException {
        return readDataFromResponseStream(createResponseReader(connection));
    }

    private static String readDataFromResponseStream(BufferedReader responseReader) {
        StringBuilder builder = new StringBuilder();
        String line;
        try {
            while ((line = responseReader.readLine()) != null) {
                builder.append(line);
            }
            responseReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return builder.toString();
    }

    private static BufferedReader createResponseReader(HttpURLConnection connection) throws IOException{
        BufferedReader in=null;
        try {
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return in;
    }

    private static URL createUrl(String mainUrl, String stringParams) throws IOException{
        URL url=null;
        try {
            url = new URL(mainUrl + stringParams);
        } catch (MalformedURLException e) {
           e.printStackTrace();
        }
        return url;
    }
}
