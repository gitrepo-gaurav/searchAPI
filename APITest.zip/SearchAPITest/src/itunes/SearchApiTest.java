package itunes;

import innerparameter.Media;
import outerparameters.SearchParameters;
import result.MultipleResults;

import org.testng.Assert;
import org.testng.annotations.Test;

public class SearchApiTest {
    @Test
    public void testSearch() throws Exception {
        MultipleResults data = SearchApi.search(createParams("michael", "jackson"));
        //logger.info(data.toString());
        Assert.assertNotNull(data);
        System.out.println(data.toString());
    }


    private SearchParameters createParams(String... terms) {
        SearchParameters searchParams = new SearchParameters();
        for (String term : terms) {
            searchParams.addQueryTerm(term);
        }
        searchParams.setMedia(Media.MUSIC);
  
        return searchParams;
    }
}
