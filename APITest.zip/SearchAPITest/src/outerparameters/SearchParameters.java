package outerparameters;

import innerparameter.Countries;
import innerparameter.Language;
import innerparameter.Media;

import java.util.ArrayList;
import java.util.List;



public class SearchParameters implements Parameters {
    private List<String> terms = new ArrayList<>();
    private Countries country;
    private Media media;

    private Language lang;

    public void addQueryTerm(String queryTerm) {
        terms.add(queryTerm);
    }

    public List<String> getTerms() {
        return terms;
    }

    public Countries getCountry() {
        return country == null ? country : country;
    }

    public void setCountry(Countries country) {
        this.country = country;
    }


    public Media getMedia() {
        return media == null ? media : media;
    }

    public void setMedia(Media media) {
        this.media = media;
    }


    public Language getLang() {
        return lang == null ? lang : lang;
    }

    public void setLang(Language lang) {
        this.lang = lang;
    }

}
