package outerparameters;


public class LookUpParameters implements Parameters {
}
