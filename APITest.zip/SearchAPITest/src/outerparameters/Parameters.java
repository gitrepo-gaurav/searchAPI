package outerparameters;


public interface Parameters {
}
