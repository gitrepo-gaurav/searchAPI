package innerparameter;

public class Countries implements Para {
    private final String country;

    public Countries(String country) {
        this.country = country;
    }

    @Override
    public String createSearchParameter() {
        return "country=" + country;
    }
}
