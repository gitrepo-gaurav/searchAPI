package innerparameter;


public interface Para {
    String createSearchParameter();
}
