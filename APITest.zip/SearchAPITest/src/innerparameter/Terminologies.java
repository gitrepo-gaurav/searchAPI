package innerparameter;

import java.util.List;

import utilities.Util4URL;


public class Terminologies implements Para {
    private final static String predicate = "term=";
    private List<String> queryValues;

    public Terminologies(List<String> queryValues) {
        this.queryValues = queryValues;
    }

    private String makeQueryString(List<String> queryValues) {
        final StringBuilder stringBuilder = new StringBuilder();
        for (String queryValue : queryValues) {
            stringBuilder.append(queryValue).append(" ");
        }
        return stringBuilder.toString();
    }

    @Override
    public String createSearchParameter() {
        String query = makeQueryString(queryValues);
        query = Util4URL.encodeUrl(query);
        return predicate + query;
    }
}
