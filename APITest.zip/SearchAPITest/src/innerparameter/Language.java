package innerparameter;


public enum Language implements Para {
    ENGLISH("en_us"), JAPAN("ja_jp");
    public final String value;

    private Language(String value) {
        this.value = value;
    }


	public String createSearchParameter() {
		return "lang=" + value;
	}
}
